# Firefox desktop release checks

Use desktop Firefox 153 or newer in a separate tester profile. Record Firefox version, OS, extension version, steps, and results. No Android testing is included.

- Install the Mozilla-signed XPI using about:addons → Tools for all add-ons → Install Add-on From File. Confirm there are no manifest/startup errors and settings show Firefox desktop, accurate selected/omitted counts, and both filter sources.
- Open the toolbar popup and Settings. Check Show Firefox access instructions explains how to open the Add-ons Manager.
- Pause/resume: network count becomes zero then restores. Caregiver Shield adds/removes its reserved rules. Defaults: Shield on, Caregiver off, nag hiding on, Advanced Protection off.
- Request optional site access. Deny first; network protection should remain active. Grant YouTube only and confirm unrelated websites have no scripts. Grant general cleanup only when intended; reload pages afterward.
- On permitted pages, test advertisement spaces, ordinary article visibility, consent overlays, scrolling, log-in controls, and frames. Toggle nag hiding and Shield on already-open pages and check CSS removal/reapplication. Navigate rapidly and verify CSS does not leak into a different document.
- On real YouTube desktop pages, test recognized Skip Ad controls, consecutive ads, ads without Skip, ordinary playback, Shorts, player replacement, background tabs, and navigation. Disable Advanced Protection on an open page. Check its independence from Shield.
- Test an offline/failed update; rules should remain. Terminate the background script in about:debugging, then reopen controls; settings/rules should reconcile.
- Restore previous filters after an update and confirm current switches remain unchanged. Update again before finishing.
- Revoke site access and reload affected pages. Check Firefox restricted pages. Private-window access is separate; test it only when explicitly enabled.
- Confirm the signed candidate stays installed and enabled after fully quitting and reopening Firefox. Test a future newer signed candidate for in-place updates, permission prompts, and preserved preferences; upgrades are manual during this beta.
- Review attribution, public support/privacy links, data disclosure, minimum Firefox version, and reduced coverage before approving Mozilla submission.
