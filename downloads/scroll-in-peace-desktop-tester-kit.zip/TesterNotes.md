# Scroll in Peace tester notes

Candidate editions: Safari 1.0 (review build 15; final distribution build pending), Chrome/Edge 1.0.2, Firefox desktop 1.0.1. Test on the browser and device named below. Installing one edition does not activate another browser.

## Supported test scope

| Edition | Where to test | Installation |
| --- | --- | --- |
| Safari app | iPhone/iPad with iOS/iPadOS 26+, Mac with macOS 26+ | Provided signed app or TestFlight candidate |
| Chrome/Edge | Desktop browser | Load unpacked Chrome-Edge/extension folder |
| Firefox | Desktop Firefox 153+ | Install signed Firefox/Scroll-in-Peace-Firefox-Desktop-1.0.1-signed.xpi |

No Android work or testing is included. Scroll’s Safari app does not provide blocking in Chrome, Edge, or Firefox on iPhone/iPad. Firefox versions below 153, including older ESR versions, are outside this first candidate. Desktop browser automation and Firefox direct checks were run on Mac; Windows/Linux need their own test results.

## Safari setup

1. Install the provided Safari candidate and launch Scroll in Peace once. Use a spare device or separate test installation for clean-install checks; retain existing personal data.
2. On Mac: **Safari → Settings → Extensions**. On iPhone/iPad: **Settings → Apps → Safari → Extensions**.
3. Enable **Scroll in Peace Filters** (the Ads & Cleanup blocker) and **Scroll in Peace Privacy**.
4. Optionally enable **Scroll in Peace Advanced Protection**, grant its YouTube access in Safari, and enable Advanced Protection in Scroll. This operates separately from the two content blockers.
5. Keep the main Shield on. Return to Scroll and confirm it identifies the real Safari protection state.
6. Run **Update Filters Now**. Wait for completion. A failure should report an error and retain previously installed protection.
7. Reload existing Safari pages. Avoid launching several installed copies of Scroll while testing on Mac.

## Chrome and Edge setup

1. Extract the desktop tester kit. In desktop Chrome open `chrome://extensions`; in desktop Edge open `edge://extensions`.
2. Enable **Developer mode**, choose **Load unpacked**, and select **Chrome-Edge/extension**. This folder contains `manifest.json`; selecting the whole kit will not work.
3. Pin Scroll in Peace in the browser’s Extensions menu and open it. EasyList, EasyPrivacy, and Scroll site fixes should download automatically. Use **Update filters** to retry.
4. Choose **Enable page cleanup**, or **Allow YouTube** for access limited to YouTube. Reload already-open pages after granting access.
5. Advanced Protection starts off. Enable it if testing available Skip Ad controls.
6. For an existing unpacked installation, copy the new runtime files into the same extension folder already in use, then click its Reload button and reload test pages. Loading a different folder path can create a separate extension with separate settings. Keep only one enabled Scroll extension per browser profile.

## Firefox setup

1. Update desktop Firefox to 153 or newer and extract the desktop tester kit.
2. If Scroll was loaded temporarily, fully quit and reopen Firefox first. This ends the old temporary installation.
3. Open `about:addons`, select **Extensions**, click the gear button (**Tools for all add-ons**), and choose **Install Add-on From File**.
4. Select **Firefox/Scroll-in-Peace-Firefox-Desktop-1.0.1-signed.xpi** from the extracted kit. Accept the installation prompt if you want to grant its listed permissions. The package is signed by Mozilla; do not disable signature verification.
**Firefox download permission check:** On `about:addons`, click Scroll in Peace’s name → **Permissions and data**. Confirm access to `https://easylist.to` and `https://jocular-sherbet-13dd23.netlify.app` is on. Firefox may leave the newly added support-site permission off after upgrading from 1.0.0. Enable that specific permission if needed, then use **Update filters**. Firefox account sign-in is not required. Mac download-folder settings are separate.

5. Open Scroll from Firefox’s Extensions menu. It should show **FIREFOX DESKTOP**, **SHIELD ACTIVE**, and the maintained sources after the automatic update. Use **Update filters** to retry.
6. Choose **Enable page cleanup** to hide ad spaces, or **Allow YouTube** for access limited to YouTube. Accept only the site access you intend to allow and reload already-open pages. A disabled **Page cleanup allowed** button means access is already granted.
7. Advanced Protection starts off. Enable it if testing recognized visible, enabled Skip Ad controls; it does not seek through ads without a Skip control.
8. Fully quit and reopen Firefox. Scroll should remain installed and enabled. You do not need to reload it through `about:debugging`.
9. Future beta upgrades are manual: download the updated kit and install its newer signed XPI through the same Add-ons Manager action. This beta has no automatic extension-update URL. Filter-list updates are separate and automatic.

## How to judge readiness

Browser rule budgets differ. A full-budget Chrome/Edge generation normally shows **29,997** installed network rules, or **30,000** with Caregiver Shield. Firefox shows **4,997**, or **5,000** with Caregiver Shield. Safari uses its own larger rule set. Lists change, so treat displayed source reports as current rather than expecting an exact Safari count. Cosmetic selectors use a separate layer. Firefox’s current network coverage is substantially smaller; report remaining advertisements and affected sites rather than assuming parity with Safari or Chromium.

Run these checks in each edition:

- Confirm the edition’s maintained sources update, counts are visible, and no extension errors remain.
- Browse ordinary and ad-heavy sites. Check articles, scrolling, sign-in, embedded media, ad spaces, and consent overlays.
- Pause the Shield. Confirm the network count becomes zero and permitted-page cleanup is removed. Resume it and confirm protection returns.
- Toggle Caregiver Shield and nag-screen hiding. Verify nag effects change on already-open permitted pages.
- Deny optional site access first; network blocking should remain. Grant only the access you intend to test. Revoke it and reload the page to confirm scripts stop.
- Test YouTube with a visible Skip Ad control, consecutive ads, ads without Skip, and videos without ads. Look for normal playback, at most one activation of each recognized Skip control, and no unexpected seeking. Test Advanced Protection off and on independently from Shield.
- Try a failed/offline update. Existing filters should remain. Restore previous filters after an update, confirm current switches are retained, then update again before finishing.
- Reopen the app/browser. For Firefox, confirm the signed extension remains enabled after a full browser restart. Test future newer signed versions for preserved preferences during in-place upgrades. Terminating its background script in about:debugging should allow controls to recover with the same settings and rules.
- Test private browsing separately only if you explicitly enable access in the browser.

Use the browser-specific checklists for the full release pass. Real YouTube playback, native grants/revocation, private browsing, and signed-install updates require tester results; fixture tests do not establish all of these.

## Sending feedback

Contact **420productions.zippy.brett@protonmail.com**. Include device/OS, browser version, edition/version, steps, expected result, actual result, and the displayed update/error status. A redacted screenshot can help. Avoid sending browsing history, account details, or private page content.

Developer: Claude Alfred Henderson. Public support/privacy links are https://jocular-sherbet-13dd23.netlify.app/ and https://jocular-sherbet-13dd23.netlify.app/privacy.html. The shared support/privacy site was updated on September 14, 2026 to include Scroll and its dedicated contact.

## Scroll site fixes updates

Chrome/Edge 1.0.2 and the included Mozilla-signed Firefox 1.0.1 download the Scroll-maintained site-fixes list as well as EasyList and EasyPrivacy. Safari does not use this list yet. Firefox testers with signed 1.0.0 should install the newer signed XPI through Add-ons Manager. The same extension ID preserves an existing signed installation; approve its new support-site download permission if requested.

For Chrome/Edge, update the files in the same unpacked extension folder, click Reload on the extensions page, and approve the new support-site download permission if requested. For Firefox, also confirm the support-site switch under about:addons → Scroll in Peace → Permissions and data is on, even if an upgrade prompt did not appear. Click Update filters, then check the Scroll site fixes source and version in Filter details & settings. Reload the affected page after receiving a fix. Automatic updates normally retry within six hours while the browser is running. Failed updates keep the previous generation.
