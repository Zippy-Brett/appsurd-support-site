(() => {
  const key = "__scrollInPeaceCosmeticV1";
  if (globalThis[key]) { globalThis[key](); return; }
  let css = "", queue = Promise.resolve();
  const refresh = (clear = false) => {
    queue = queue.catch(() => {}).then(async () => {
      const response = await chrome.runtime.sendMessage({kind: "applyCosmetics", previousCSS: css, clear});
      if (response?.ok && typeof response.css === "string") css = response.css;
    });
    return queue;
  };
  globalThis[key] = refresh;
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.kind !== "refreshProtection" && message?.kind !== "clearProtectionStyles") return;
    refresh(message.kind === "clearProtectionStyles").then(() => sendResponse({done: true}), () => sendResponse({done: false}));
    return true;
  });
  window.addEventListener("pageshow", () => refresh().catch(() => {}));
  refresh().catch(() => {});
})();
