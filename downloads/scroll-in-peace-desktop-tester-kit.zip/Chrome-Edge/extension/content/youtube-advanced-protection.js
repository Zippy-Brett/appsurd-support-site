// Scroll in Peace Advanced Protection production content script.
// Chromium adapter: settings come from the extension; production diagnostics stay disabled.
(() => {
    "use strict";

    const host = location.hostname.toLowerCase();
    if (host !== "youtube.com" && !host.endsWith(".youtube.com")) return;

    // Keep the established page-level guard so an extension update cannot
    // leave two observers active and issue duplicate Skip Ad activations.
    const installationKey = "__scrollInPeaceAdvancedProtectionV2";
    if (window[installationKey]) return;
    window[installationKey] = true;

    const signalSelectors = new Map([
        ["element:video-ads", ".video-ads"],
        ["element:ytp-ad-module", ".ytp-ad-module"],
        ["element:ytp-ad-player-overlay", ".ytp-ad-player-overlay"],
        ["element:ytp-ad-text", ".ytp-ad-text"],
        ["element:ytp-ad-preview-container", ".ytp-ad-preview-container"],
        ["element:ytp-ad-duration-remaining", ".ytp-ad-duration-remaining"],
        ["element:ytp-ad-skip-button", ".ytp-ad-skip-button"],
        ["element:ytp-skip-ad-button", ".ytp-skip-ad-button"],
        ["element:ytp-ad-skip-button-modern", ".ytp-ad-skip-button-modern"],
        ["element:ytm-player-ads", "ytm-player-ads"],
        ["element:ytm-ad-player-overlay", "ytm-ad-player-overlay"]
    ]);
    const playerClasses = ["ad-showing", "ad-interrupting", "ad-created"];
    const positiveAdStateClasses = ["ad-showing", "ad-interrupting"];
    const noSkipObservationWindowMs = 2300;
    const noSkipDurationMinimumSeconds = 5;
    const noSkipDurationMaximumSeconds = 90;
    // YouTube can leave the ad classes and skip overlay in place for tens of
    // seconds after activation. Keep an early checkpoint for diagnostics, but
    // do not call a slow transition a failure until this final deadline.
    const skipTransitionPendingMs = 4200;
    const skipTransitionTimeoutMs = 45000;
    const handoffTracePollMs = 250;
    const handoffTraceTimeoutMs = 60000;
    const maximumMediaTraceEvents = 64;
    const adInstanceTransitionWindowMs = 5000;
    const maximumAdInstanceHistory = 8;
    const adInstanceTransitionReason = "emptied-time-reset-overlay-changed-new-ad-metadata";
    const skipControls = [
        { selector: "button.ytp-ad-skip-button-modern", signal: "element:ytp-ad-skip-button-modern" },
        { selector: "button.ytp-ad-skip-button", signal: "element:ytp-ad-skip-button" },
        { selector: "button.ytp-skip-ad-button", signal: "element:ytp-skip-ad-button" }
    ];
    const activeAdContainerSelector = [
        ".ytp-ad-player-overlay",
        ".ytp-ad-player-overlay-skip-or-preview",
        ".ytp-ad-skip-ad-slot",
        ".ytp-ad-skip-button-slot",
        ".ytp-ad-module",
        ".video-ads",
        "ytm-ad-player-overlay",
        "ytm-player-ads"
    ].join(",");
    const recognizedAdDOMSignals = new Set([
        "element:video-ads",
        "element:ytp-ad-module",
        "element:ytp-ad-player-overlay",
        "element:ytm-player-ads",
        "element:ytm-ad-player-overlay"
    ]);
    const mediaTraceEventNames = [
        "seeking",
        "seeked",
        "durationchange",
        "loadedmetadata",
        "emptied",
        "waiting",
        "stalled",
        "canplay",
        "playing",
        "ended"
    ];

    const identityMaps = {
        media: new WeakMap(),
        player: new WeakMap(),
        overlay: new WeakMap()
    };
    const identityCounters = { media: 0, player: 0, overlay: 0 };
    const opaqueIdentity = (element, kind) => {
        if (!(element instanceof Element)) return null;
        let identity = identityMaps[kind].get(element);
        if (!identity) {
            identityCounters[kind] += 1;
            identity = `${kind}-${identityCounters[kind]}`;
            identityMaps[kind].set(element, identity);
        }
        return identity;
    };

    const safeToken = value => {
        const token = String(value || "").trim();
        return /^[A-Za-z0-9_.:-]{1,120}$/.test(token) ? token : null;
    };
    const adSpecificToken = value => {
        const token = safeToken(value);
        if (!token) return null;
        const lower = token.toLowerCase();
        return lower.includes("ad-") || lower.includes("-ad") || lower === "video-ads" || lower.includes("advert")
            ? token
            : null;
    };
    const parentSummary = element => {
        const parents = [];
        let parent = element.parentElement;
        while (parent && parents.length < 4) {
            parents.push({
                tag: safeToken(parent.tagName.toLowerCase()),
                id: safeToken(parent.id),
                classes: Array.from(parent.classList || []).map(safeToken).filter(Boolean).slice(0, 16)
            });
            parent = parent.parentElement;
        }
        return parents;
    };
    const ariaMarker = element => {
        const label = element.getAttribute("aria-label") || "";
        if (/skip\s+(this\s+)?ad/i.test(label)) return "skip-ad";
        if (/advertisement|advertising/i.test(label)) return "advertisement";
        if (/sponsored/i.test(label)) return "sponsored";
        return null;
    };
    const describe = element => {
        if (!(element instanceof Element)) return null;
        const tag = safeToken(element.tagName.toLowerCase());
        const id = safeToken(element.id);
        const classes = Array.from(element.classList || []).map(adSpecificToken).filter(Boolean).slice(0, 16);
        const marker = ariaMarker(element);
        if (!adSpecificToken(tag) && !adSpecificToken(id) && classes.length === 0 && !marker) return null;
        const dataAttributes = {};
        ["data-ad-state", "data-ad-type", "data-layer", "data-player-state"].forEach(name => {
            const value = safeToken(element.getAttribute(name));
            if (value) dataAttributes[name] = value;
        });
        return {
            tag,
            id,
            classes,
            dataAttributes,
            role: safeToken(element.getAttribute("role")),
            ariaMarker: marker,
            parents: parentSummary(element)
        };
    };
    const pageKind = () => {
        if (location.pathname.startsWith("/watch")) return "watch";
        if (location.pathname.startsWith("/shorts")) return "shorts";
        return "other";
    };
    const playerHasPositiveAdState = player => Boolean(
        player && positiveAdStateClasses.some(className => player.classList.contains(className))
    );
    const findRecognizedSkipControl = player => {
        if (!player) return null;
        let firstRecognized = null;
        for (const configuration of skipControls) {
            const element = player.querySelector(configuration.selector);
            if (!element) continue;
            const candidate = { ...configuration, element };
            if (!firstRecognized) firstRecognized = candidate;
            if (belongsToActiveAdOverlay(player, element) && isVisibleAndEnabled(element)) {
                return { ...candidate, actionable: true };
            }
        }
        return firstRecognized ? { ...firstRecognized, actionable: false } : null;
    };
    const belongsToActiveAdOverlay = (player, element) => {
        if (!player || !element || !player.contains(element)) return false;
        const container = element.closest(activeAdContainerSelector);
        return Boolean(container && player.contains(container));
    };
    const isVisibleAndEnabled = element => {
        if (!(element instanceof HTMLElement) || !element.isConnected) return false;
        if (element.matches(":disabled") || element.getAttribute("aria-disabled") === "true") return false;
        if (element.hidden || element.getAttribute("inert") !== null) return false;
        const style = getComputedStyle(element);
        if (style.display === "none" || style.visibility === "hidden" || style.visibility === "collapse") return false;
        if (Number.parseFloat(style.opacity || "1") <= 0 || style.pointerEvents === "none") return false;
        const rect = element.getBoundingClientRect();
        return rect.width > 0 && rect.height > 0 && element.getClientRects().length > 0;
    };

    let diagnosticsEnabled = false;
    let interventionEnabled = false;
    let lastFingerprint = "";
    let scheduled = false;
    let activeCycle = null;
    let outcomeTimers = [];
    let tracePollTimer = null;
    let lastNormalVideoDuration = null;
    let activePod = null;

    const findAdOverlay = player => player?.querySelector(
        ".ytp-ad-player-overlay, .ytp-ad-player-overlay-skip-or-preview, " +
        ".ytp-ad-skip-ad-slot, ytm-ad-player-overlay"
    ) ?? null;

    const collectState = () => {
        const player = document.querySelector("#movie_player, .html5-video-player, ytm-player");
        const signals = [];
        playerClasses.forEach(className => {
            if (player?.classList.contains(className)) signals.push(`player-class:${className}`);
        });

        const matchedElements = [];
        signalSelectors.forEach((selector, signal) => {
            const element = player?.querySelector(selector) || document.querySelector(selector);
            if (!element) return;
            signals.push(signal);
            const description = describe(element);
            if (description) matchedElements.push(description);
        });
        signals.sort();

        return {
            player,
            positiveAdState: playerHasPositiveAdState(player),
            signals,
            matchedElements,
            skipControl: findRecognizedSkipControl(player),
            hasRecognizedAdDOM: signals.some(signal => recognizedAdDOMSignals.has(signal)),
            video: document.querySelector("video.html5-main-video, video"),
            overlay: findAdOverlay(player)
        };
    };

    const elapsedMilliseconds = (later, earlier) => {
        if (!Number.isFinite(later) || !Number.isFinite(earlier)) return null;
        return Math.max(0, Math.min(3600000, Math.round(later - earlier)));
    };

    const orderedElapsedMilliseconds = (later, earlier) => {
        if (!Number.isFinite(later) || !Number.isFinite(earlier) || later < earlier) return null;
        return elapsedMilliseconds(later, earlier);
    };

    const finiteMediaNumber = value => Number.isFinite(value) && value >= 0 ? value : null;
    const seekableBounds = mediaElement => {
        try {
            const ranges = mediaElement?.seekable;
            if (!ranges || ranges.length === 0) return { start: null, end: null };
            const index = ranges.length - 1;
            return {
                start: finiteMediaNumber(ranges.start(index)),
                end: finiteMediaNumber(ranges.end(index))
            };
        } catch (_) {
            return { start: null, end: null };
        }
    };
    const traceOffset = (trace, at = performance.now()) => elapsedMilliseconds(at, trace?.startedAt);
    const seekTraceDiagnosticFields = cycle => {
        const trace = cycle?.intervention?.trace;
        if (!trace) return { seekTrace: null };
        return {
            seekTrace: {
                mode: trace.mode,
                currentTimeBeforeAssignment: trace.currentTimeBeforeAssignment ?? null,
                requestedTarget: trace.requestedTarget ?? null,
                currentTimeAfterAssignment: trace.currentTimeAfterAssignment ?? null,
                seekableStartBeforeAssignment: trace.seekableStartBeforeAssignment ?? null,
                seekableEndBeforeAssignment: trace.seekableEndBeforeAssignment ?? null,
                seekableStartAfterAssignment: trace.seekableStartAfterAssignment ?? null,
                seekableEndAfterAssignment: trace.seekableEndAfterAssignment ?? null,
                assignmentAppearedAccepted: trace.assignmentAppearedAccepted ?? null,
                currentTimeSnapBackDetected: trace.currentTimeSnapBackDetected,
                mediaIdentityBefore: trace.mediaIdentityBefore,
                mediaIdentityImmediatelyAfter: trace.mediaIdentityImmediatelyAfter ?? null,
                latestMediaIdentity: trace.latestMediaIdentity ?? null,
                playerIdentityBefore: trace.playerIdentityBefore,
                playerIdentityImmediatelyAfter: trace.playerIdentityImmediatelyAfter ?? null,
                latestPlayerIdentity: trace.latestPlayerIdentity ?? null,
                overlayIdentityBefore: trace.overlayIdentityBefore,
                overlayIdentityImmediatelyAfter: trace.overlayIdentityImmediatelyAfter ?? null,
                latestOverlayIdentity: trace.latestOverlayIdentity ?? null,
                mediaElementReplaced: trace.mediaElementReplaced,
                playerElementReplaced: trace.playerElementReplaced,
                adOverlayElementReplaced: trace.adOverlayElementReplaced,
                adOverlayRemoved: trace.adOverlayRemoved,
                durationBeforeAssignment: trace.durationBeforeAssignment ?? null,
                latestDuration: trace.latestDuration ?? null,
                requestedVideoDuration: trace.requestedVideoDuration ?? null,
                requestedDurationFirstObservedMs: elapsedMilliseconds(
                    trace.requestedDurationFirstObservedAt,
                    trace.startedAt
                ),
                adPlaybackEndedToAdStateClearedMs: orderedElapsedMilliseconds(
                    trace.adStateClearedAt,
                    trace.adPlaybackEndedAt
                ),
                adStateClearedToRequestedMediaAvailableMs: orderedElapsedMilliseconds(
                    trace.requestedMediaAvailableAt,
                    trace.adStateClearedAt
                ),
                requestedMediaAvailableToPlaybackStartMs: orderedElapsedMilliseconds(
                    trace.requestedPlaybackStartedAt,
                    trace.requestedMediaAvailableAt
                ),
                observationOutcome: trace.observationOutcome,
                events: trace.events.slice(-maximumMediaTraceEvents)
            }
        };
    };

    const skipControlHistoryEntry = cycle => ({
        adInstanceIndex: cycle.adInstanceIndex,
        skipControlEverSeen: cycle.skipControlEverSeen,
        skipControlActionableEverSeen: Boolean(cycle.skipControlActionableDetectedAt),
        skipAttempted: Boolean(cycle.lastAttempt),
        recognizedSelector: cycle.lastAttempt?.selector ?? cycle.recognizedSkipSelector ?? null,
        outcome: cycle.lastAttempt?.outcome
            ?? (cycle.skipControlEverSeen ? "observed-not-attempted" : "not-observed")
    });

    const interventionHistoryEntry = (cycle, outcome = null, advancedPod = false) => ({
        adInstanceIndex: cycle.adInstanceIndex,
        method: cycle.lastAttempt ? "skip-control" : cycle.intervention?.method ?? "none",
        attempted: Boolean(cycle.lastAttempt || cycle.intervention?.attempted),
        outcome: outcome
            ?? cycle.lastAttempt?.outcome
            ?? cycle.intervention?.outcome
            ?? cycle.intervention?.stopReason
            ?? (cycle.intervention?.attempted ? "observing" : "not-attempted"),
        advancedPod
    });

    const currentPodHistory = cycle => {
        if (!cycle?.pod) {
            return { skipControls: [], interventions: [] };
        }
        return {
            skipControls: [
                ...cycle.pod.skipControlHistory,
                skipControlHistoryEntry(cycle)
            ].slice(-maximumAdInstanceHistory),
            interventions: [
                ...cycle.pod.interventionHistory,
                interventionHistoryEntry(cycle)
            ].slice(-maximumAdInstanceHistory)
        };
    };

    const cycleDiagnosticFields = cycle => {
        const history = currentPodHistory(cycle);
        return {
        adInstanceIndex: cycle?.adInstanceIndex ?? null,
        newAdInstanceDetectionReason: cycle?.newAdInstanceDetectionReason ?? null,
        previousAdInstanceOutcome: cycle?.previousAdInstanceOutcome ?? null,
        previousInterventionAdvancedPod: cycle?.previousInterventionAdvancedPod ?? null,
        adInstanceSkipControlHistory: history.skipControls,
        adInstanceInterventionHistory: history.interventions,
        skipControlPresentAtDetection: cycle?.skipControlPresentAtDetection ?? null,
        adStateToSkipControlMs: elapsedMilliseconds(
            cycle?.skipControlDetectedAt,
            cycle?.adStateDetectedAt
        ),
        skipControlToActionableMs: elapsedMilliseconds(
            cycle?.skipControlActionableDetectedAt,
            cycle?.skipControlDetectedAt
        ),
        unskippableDetected: cycle?.unskippableDetected ?? null,
        interventionMethod: cycle?.intervention?.method ?? null,
        interventionAttempted: cycle?.intervention?.attempted ?? null,
        originalAdDuration: cycle?.initialVideoDuration ?? null,
        originalAdCurrentTime: cycle?.initialVideoCurrentTime ?? null,
        interventionAdStateCleared: cycle?.intervention?.adStateCleared ?? null,
        interventionPlaybackResumed: cycle?.intervention?.playbackResumed ?? null,
        interventionStopReason: cycle?.intervention?.stopReason ?? null,
        ...seekTraceDiagnosticFields(cycle)
        };
    };

    const diagnosticFieldsForAttempt = (attempt, cycle = activeCycle) => ({
        skipAttempted: Boolean(attempt),
        skipSucceeded: attempt?.skipSucceeded ?? null,
        recognizedSkipSelector: attempt?.selector ?? null,
        adStateClearedAfterAttempt: attempt?.adStateClearedAfterAttempt ?? null,
        playbackResumedAfterAttempt: attempt?.playbackResumedAfterAttempt ?? null,
        skipOutcome: attempt?.outcome ?? "not-attempted",
        skipControlPresentAtDetection: attempt?.skipControlPresentAtDetection
            ?? cycle?.skipControlPresentAtDetection
            ?? null,
        skipControlPresentAtActivation: attempt?.skipControlPresentAtActivation ?? null,
        skipControlVisibleAndEnabledAtActivation: attempt?.skipControlVisibleAndEnabledAtActivation ?? null,
        skipControlPresentAtOutcome: attempt?.skipControlPresentAtOutcome ?? null,
        adStateToSkipControlMs: elapsedMilliseconds(
            attempt?.skipControlDetectedAt,
            attempt?.adStateDetectedAt
        ) ?? elapsedMilliseconds(cycle?.skipControlDetectedAt, cycle?.adStateDetectedAt),
        skipControlToClickMs: elapsedMilliseconds(
            attempt?.clickAt,
            attempt?.skipControlDetectedAt
        ),
        skipControlActionableToClickMs: elapsedMilliseconds(
            attempt?.clickAt,
            attempt?.skipControlActionableDetectedAt
        ),
        clickToAdStateClearedMs: elapsedMilliseconds(
            attempt?.adStateClearedAt,
            attempt?.clickAt
        ),
        unskippableDetected: cycle?.unskippableDetected ?? null,
        interventionMethod: cycle?.intervention?.method ?? null,
        interventionAttempted: cycle?.intervention?.attempted ?? null,
        originalAdDuration: cycle?.initialVideoDuration ?? null,
        originalAdCurrentTime: cycle?.initialVideoCurrentTime ?? null,
        interventionAdStateCleared: cycle?.intervention?.adStateCleared ?? null,
        interventionPlaybackResumed: cycle?.intervention?.playbackResumed ?? null,
        interventionStopReason: cycle?.intervention?.stopReason ?? null
    });

    const sendDiagnostic = (state, interventionFields, fallbackSignals = []) => {
        if (!diagnosticsEnabled) return;
        const signals = state.signals.length > 0 ? state.signals : fallbackSignals;
        if (signals.length === 0) return;

        const video = document.querySelector("video.html5-main-video, video");
        const payload = {
            pageKind: pageKind(),
            adStateSignals: signals,
            // This is the state observed while assembling this diagnostic
            // snapshot. It is intentionally distinct from the lifecycle
            // fields below, which describe detection, activation, and outcome.
            skipControlPresent: Boolean(state.skipControl),
            ...cycleDiagnosticFields(activeCycle),
            ...interventionFields,
            videoCurrentTime: Number.isFinite(video?.currentTime) ? video.currentTime : null,
            videoDuration: Number.isFinite(video?.duration) ? video.duration : null,
            videoPaused: typeof video?.paused === "boolean" ? video.paused : null,
            videoReadyState: Number.isInteger(video?.readyState) ? video.readyState : null,
            elements: state.matchedElements
        };
        const fingerprint = JSON.stringify({
            pageKind: payload.pageKind,
            adStateSignals: payload.adStateSignals,
            skipControlPresent: payload.skipControlPresent,
            skipAttempted: payload.skipAttempted,
            skipSucceeded: payload.skipSucceeded,
            recognizedSkipSelector: payload.recognizedSkipSelector,
            adStateClearedAfterAttempt: payload.adStateClearedAfterAttempt,
            playbackResumedAfterAttempt: payload.playbackResumedAfterAttempt,
            skipOutcome: payload.skipOutcome,
            skipControlPresentAtDetection: payload.skipControlPresentAtDetection,
            skipControlPresentAtActivation: payload.skipControlPresentAtActivation,
            skipControlVisibleAndEnabledAtActivation: payload.skipControlVisibleAndEnabledAtActivation,
            skipControlPresentAtOutcome: payload.skipControlPresentAtOutcome,
            adStateToSkipControlMs: payload.adStateToSkipControlMs,
            skipControlToClickMs: payload.skipControlToClickMs,
            clickToAdStateClearedMs: payload.clickToAdStateClearedMs,
            skipControlToActionableMs: payload.skipControlToActionableMs,
            skipControlActionableToClickMs: payload.skipControlActionableToClickMs,
            unskippableDetected: payload.unskippableDetected,
            interventionMethod: payload.interventionMethod,
            interventionAttempted: payload.interventionAttempted,
            originalAdDuration: payload.originalAdDuration,
            originalAdCurrentTime: payload.originalAdCurrentTime,
            interventionAdStateCleared: payload.interventionAdStateCleared,
            interventionPlaybackResumed: payload.interventionPlaybackResumed,
            interventionStopReason: payload.interventionStopReason,
            adInstanceIndex: payload.adInstanceIndex,
            newAdInstanceDetectionReason: payload.newAdInstanceDetectionReason,
            previousAdInstanceOutcome: payload.previousAdInstanceOutcome,
            previousInterventionAdvancedPod: payload.previousInterventionAdvancedPod,
            adInstanceSkipControlHistory: payload.adInstanceSkipControlHistory,
            adInstanceInterventionHistory: payload.adInstanceInterventionHistory,
            seekTrace: payload.seekTrace
        });
        if (fingerprint === lastFingerprint) return;
        lastFingerprint = fingerprint;
        chrome.runtime.sendMessage({ kind: "youtubeAdState", payload }).catch(() => {});
    };

    const playbackLikelyResumed = (attempt, state) => {
        if (!attempt) return false;
        const video = document.querySelector("video.html5-main-video, video");
        if (!video || video.paused) return false;

        // YouTube can leave the player classes behind briefly after the click.
        // Treat a playing video with no ad overlay and a changed/reset timeline
        // as a conservative indication that normal playback resumed, even if
        // the ad classes have not been removed yet.
        const overlay = state.player?.querySelector(
            ".ytp-ad-player-overlay, .ytp-ad-player-overlay-skip-or-preview, " +
            ".ytp-ad-skip-ad-slot, .ytp-ad-skip-button-slot"
        );
        const overlayPresent = Boolean(overlay && isVisibleAndEnabled(overlay));
        if (overlayPresent || state.skipControl?.actionable) return false;

        const durationChanged = Number.isFinite(attempt.initialVideoDuration)
            && Number.isFinite(video.duration)
            && Math.abs(video.duration - attempt.initialVideoDuration) > 1;
        const timeReset = Number.isFinite(attempt.initialVideoCurrentTime)
            && attempt.initialVideoCurrentTime > 1
            && Number.isFinite(video.currentTime)
            && video.currentTime < 1;
        return durationChanged || timeReset;
    };

    const finishAttemptObservation = (attempt, state, adStateCleared, phase = "observe") => {
        if (!attempt) return;
        // A successful playback transition is terminal for intervention, but
        // we still accept one later callback to record the exact ad-class
        // removal time when YouTube clears its state asynchronously.
        if (attempt.terminal && !attempt.successReported) return;
        const now = performance.now();
        if (adStateCleared && !Number.isFinite(attempt.adStateClearedAt)) {
            attempt.adStateClearedAt = now;
        }
        const playbackResumed = playbackLikelyResumed(attempt, state);
        const succeeded = adStateCleared || playbackResumed;
        if (attempt.successReported) {
            // A successful playback transition can precede YouTube removing
            // its ad classes. Keep observing so the final report can include
            // the actual ad-state-cleared timing, without another click.
            if (adStateCleared && !attempt.outcomeAfterClearReported) {
                attempt.skipControlPresentAtOutcome = Boolean(state.skipControl);
                attempt.outcomeAfterClearReported = true;
                sendDiagnostic(state, diagnosticFieldsForAttempt(attempt), attempt.initialSignals);
            }
            return;
        }
        if (succeeded) {
            attempt.skipControlPresentAtOutcome = Boolean(state.skipControl);
            attempt.skipSucceeded = true;
            attempt.adStateClearedAfterAttempt = adStateCleared;
            attempt.playbackResumedAfterAttempt = playbackResumed;
            attempt.outcome = adStateCleared ? "ad-state-cleared" : "playback-resumed";
            attempt.successReported = true;
            attempt.terminal = true;
            attempt.outcomeAfterClearReported = adStateCleared;
            sendDiagnostic(state, diagnosticFieldsForAttempt(attempt), attempt.initialSignals);
            outcomeTimers.forEach(clearTimeout);
            outcomeTimers = [];
            return;
        }

        // A slow transition is explicitly pending, not a failed activation.
        // Keep observing and leave skipSucceeded nil until the final deadline.
        if (phase === "pending") {
            attempt.skipControlPresentAtOutcome = Boolean(state.skipControl);
            attempt.skipSucceeded = null;
            attempt.adStateClearedAfterAttempt = false;
            attempt.playbackResumedAfterAttempt = false;
            attempt.outcome = "transition-pending";
            attempt.pendingReported = true;
            sendDiagnostic(state, diagnosticFieldsForAttempt(attempt), attempt.initialSignals);
            return;
        }

        if (phase === "final") {
            attempt.skipControlPresentAtOutcome = Boolean(state.skipControl);
            attempt.skipSucceeded = false;
            attempt.adStateClearedAfterAttempt = false;
            attempt.playbackResumedAfterAttempt = false;
            attempt.outcome = "ad-state-still-present";
            attempt.terminal = true;
            sendDiagnostic(state, diagnosticFieldsForAttempt(attempt), attempt.initialSignals);
            outcomeTimers.forEach(clearTimeout);
            outcomeTimers = [];
        }
    };

    const clearOutcomeTimers = () => {
        outcomeTimers.forEach(clearTimeout);
        outcomeTimers = [];
    };

    const scheduleOutcomeCheck = attempt => {
        clearOutcomeTimers();
        [1600, skipTransitionPendingMs, skipTransitionTimeoutMs].forEach(delay => {
            outcomeTimers.push(setTimeout(() => {
                const state = collectState();
                const phase = delay === skipTransitionPendingMs
                    ? "pending"
                    : delay === skipTransitionTimeoutMs
                        ? "final"
                        : "observe";
                finishAttemptObservation(attempt, state, !state.positiveAdState, phase);
            }, delay));
        });
    };

    const conservativeAdDuration = duration => Number.isFinite(duration)
        && duration >= noSkipDurationMinimumSeconds
        && duration <= noSkipDurationMaximumSeconds;

    const hasConfirmedAdDOM = state => state.hasRecognizedAdDOM
        && state.signals.some(signal => signal === "element:video-ads" || signal === "element:ytm-player-ads")
        && state.signals.some(signal => signal === "element:ytp-ad-player-overlay" || signal === "element:ytm-ad-player-overlay");

    const sameConfirmedAdInstance = (cycle, state) => {
        const duration = state.video?.duration;
        return activeCycle === cycle
            && state.player === cycle.player
            && state.video === cycle.video
            && state.positiveAdState
            && hasConfirmedAdDOM(state)
            && !state.skipControl
            && !cycle.skipControlEverSeen
            && conservativeAdDuration(duration)
            && conservativeAdDuration(cycle.initialVideoDuration)
            && Math.abs(duration - cycle.initialVideoDuration) <= 0.5
            && Number.isFinite(state.video?.currentTime)
            && state.video.currentTime >= 0
            && state.video.currentTime < duration;
    };

    const requestedPlaybackLikelyResumed = (cycle, state) => {
        const video = state.video;
        const intervention = cycle.intervention;
        if (!video || video.paused || state.positiveAdState || !intervention) return false;
        if (!Number.isFinite(video.duration) || !Number.isFinite(intervention.originalDuration)) return false;

        const durationChanged = Math.abs(video.duration - intervention.originalDuration) > 1;
        const knownRequestedDuration = Number.isFinite(cycle.requestedVideoDurationBeforeAd)
            && Math.abs(video.duration - cycle.requestedVideoDurationBeforeAd) > 1;
        // If no pre-ad duration was observed, only accept a clearly longer
        // requested video; this avoids treating an unknown short clip as proof.
        const clearlyLongerThanAd = video.duration > noSkipDurationMaximumSeconds;
        return durationChanged && (knownRequestedDuration || clearlyLongerThanAd);
    };

    const stopNoSkipIntervention = (cycle, state, reason) => {
        if (!cycle || cycle.noSkipObservationCompleted) return;
        cycle.noSkipObservationCompleted = true;
        cycle.unskippableDetected = false;
        cycle.intervention = {
            method: "none",
            attempted: false,
            originalDuration: cycle.initialVideoDuration,
            originalCurrentTime: cycle.initialVideoCurrentTime,
            adStateCleared: null,
            playbackResumed: null,
            stopReason: reason,
            completed: true
        };
        sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
    };

    const recordMediaTraceEvent = (cycle, kind, state, mediaElement = state.video) => {
        const trace = cycle?.intervention?.trace;
        if (!diagnosticsEnabled || !trace || trace.traceCompleted) return;
        trace.events.push({
            kind,
            elapsedMs: traceOffset(trace),
            currentTime: finiteMediaNumber(mediaElement?.currentTime),
            duration: finiteMediaNumber(mediaElement?.duration),
            readyState: Number.isInteger(mediaElement?.readyState) ? mediaElement.readyState : null,
            adStateActive: state.positiveAdState,
            mediaIdentity: opaqueIdentity(mediaElement, "media"),
            playerIdentity: opaqueIdentity(state.player, "player"),
            overlayIdentity: opaqueIdentity(state.overlay, "overlay")
        });
        if (trace.events.length > maximumMediaTraceEvents) trace.events.shift();
    };

    const clearTracePoll = () => {
        if (tracePollTimer !== null) clearTimeout(tracePollTimer);
        tracePollTimer = null;
    };

    const completeSeekTrace = (cycle, state, outcome) => {
        const trace = cycle?.intervention?.trace;
        if (!trace || trace.traceCompleted) return;
        if (outcome === "trace-timeout") {
            recordMediaTraceEvent(cycle, "trace-timeout", state);
        }
        trace.traceCompleted = true;
        trace.observationOutcome = outcome;
        sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
        trace.listenerAbortController?.abort();
        clearTracePoll();
        scheduleCapture();
    };

    const requestedDurationAppeared = (cycle, state) => {
        const duration = state.video?.duration;
        const trace = cycle?.intervention?.trace;
        if (!trace || !Number.isFinite(duration) || !Number.isFinite(trace.durationBeforeAssignment)) return false;
        if (Math.abs(duration - trace.durationBeforeAssignment) <= 1) return false;
        if (!state.positiveAdState) return true;
        const matchesKnownRequestedVideo = Number.isFinite(cycle.requestedVideoDurationBeforeAd)
            && Math.abs(duration - cycle.requestedVideoDurationBeforeAd) <= 1;
        return matchesKnownRequestedVideo || duration > noSkipDurationMaximumSeconds;
    };

    const attachMediaTraceListeners = (cycle, mediaElement) => {
        const trace = cycle?.intervention?.trace;
        if (!diagnosticsEnabled || !trace || !(mediaElement instanceof HTMLMediaElement)) return;
        if (trace.observedMediaElements.has(mediaElement)) return;
        trace.observedMediaElements.add(mediaElement);

        mediaTraceEventNames.forEach(kind => {
            mediaElement.addEventListener(kind, event => {
                if (trace.traceCompleted || cycle.intervention?.trace !== trace) return;
                const state = collectState();
                observeSeekTrace(cycle, state);

                if (kind === "ended" && !Number.isFinite(trace.adPlaybackEndedAt)) {
                    trace.adPlaybackEndedAt = performance.now();
                }

                const handoffOnlyEvent = ["waiting", "stalled", "canplay", "playing"].includes(kind);
                if (!handoffOnlyEvent || Number.isFinite(trace.adPlaybackEndedAt) || Number.isFinite(trace.adStateClearedAt)) {
                    recordMediaTraceEvent(cycle, kind, state, event.currentTarget);
                }

                if (kind === "playing"
                    && Number.isFinite(trace.requestedMediaAvailableAt)
                    && !state.positiveAdState
                    && !Number.isFinite(trace.requestedPlaybackStartedAt)) {
                    trace.requestedPlaybackStartedAt = performance.now();
                    recordMediaTraceEvent(cycle, "requested-playback-started", state, event.currentTarget);
                    completeSeekTrace(cycle, state, "requested-playback-started");
                    return;
                }
                sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
            }, { signal: trace.listenerAbortController.signal });
        });
    };

    function observeSeekTrace(cycle, state) {
        const trace = cycle?.intervention?.trace;
        if (!diagnosticsEnabled || !trace || trace.traceCompleted) return;
        const now = performance.now();
        const currentMediaIdentity = opaqueIdentity(state.video, "media");
        const currentPlayerIdentity = opaqueIdentity(state.player, "player");
        const currentOverlayIdentity = opaqueIdentity(state.overlay, "overlay");

        trace.latestMediaIdentity = currentMediaIdentity;
        trace.latestPlayerIdentity = currentPlayerIdentity;
        trace.latestOverlayIdentity = currentOverlayIdentity;
        trace.latestDuration = finiteMediaNumber(state.video?.duration);
        attachMediaTraceListeners(cycle, state.video);

        if (currentMediaIdentity && currentMediaIdentity !== trace.mediaIdentityBefore && !trace.mediaElementReplaced) {
            trace.mediaElementReplaced = true;
            recordMediaTraceEvent(cycle, "media-element-replaced", state);
        }
        if (currentPlayerIdentity && currentPlayerIdentity !== trace.playerIdentityBefore && !trace.playerElementReplaced) {
            trace.playerElementReplaced = true;
            recordMediaTraceEvent(cycle, "player-element-replaced", state);
        }
        if (currentOverlayIdentity
            && trace.overlayIdentityBefore
            && currentOverlayIdentity !== trace.overlayIdentityBefore
            && !trace.adOverlayElementReplaced) {
            trace.adOverlayElementReplaced = true;
            recordMediaTraceEvent(cycle, "overlay-element-replaced", state);
        }
        if (!currentOverlayIdentity && trace.overlayIdentityBefore && !trace.adOverlayRemoved) {
            trace.adOverlayRemoved = true;
            recordMediaTraceEvent(cycle, "overlay-removed", state);
        }

        const currentTime = finiteMediaNumber(state.video?.currentTime);
        const sameAdTimeline = state.positiveAdState
            && currentMediaIdentity === trace.mediaIdentityBefore
            && Number.isFinite(state.video?.duration)
            && Math.abs(state.video.duration - trace.durationBeforeAssignment) <= 1;
        if (sameAdTimeline && Number.isFinite(currentTime)) {
            trace.maximumCurrentTimeAfterAssignment = Math.max(
                trace.maximumCurrentTimeAfterAssignment ?? currentTime,
                currentTime
            );
            const reachedAssignedTarget = trace.assignmentAppearedAccepted === true
                || (Number.isFinite(trace.requestedTarget)
                    && trace.maximumCurrentTimeAfterAssignment >= trace.requestedTarget - 0.5);
            if (reachedAssignedTarget
                && currentTime < trace.maximumCurrentTimeAfterAssignment - 1
                && !trace.currentTimeSnapBackDetected) {
                trace.currentTimeSnapBackDetected = true;
                recordMediaTraceEvent(cycle, "current-time-snap-back", state);
            }
        }

        const readyState = Number.isInteger(state.video?.readyState) ? state.video.readyState : null;
        if (readyState !== trace.lastReadyState) {
            trace.lastReadyState = readyState;
            recordMediaTraceEvent(cycle, "ready-state-change", state);
        }
        const duration = finiteMediaNumber(state.video?.duration);
        if (duration !== null
            && (trace.lastObservedDuration === null || Math.abs(duration - trace.lastObservedDuration) > 0.001)) {
            trace.lastObservedDuration = duration;
            recordMediaTraceEvent(cycle, "duration-observed", state);
        }

        if (!state.positiveAdState && !Number.isFinite(trace.adStateClearedAt)) {
            trace.adStateClearedAt = now;
            recordMediaTraceEvent(cycle, "ad-state-cleared", state);
        }
        if (requestedDurationAppeared(cycle, state) && !Number.isFinite(trace.requestedDurationFirstObservedAt)) {
            trace.requestedDurationFirstObservedAt = now;
            trace.requestedVideoDuration = state.video.duration;
            recordMediaTraceEvent(cycle, "requested-duration-observed", state);
        }
        if (!state.positiveAdState
            && Number.isFinite(trace.requestedDurationFirstObservedAt)
            && state.video?.readyState >= 1
            && !Number.isFinite(trace.requestedMediaAvailableAt)) {
            trace.requestedMediaAvailableAt = now;
            trace.requestedMediaInitialCurrentTime = finiteMediaNumber(state.video?.currentTime);
            recordMediaTraceEvent(cycle, "requested-media-available", state);
        }
        if (Number.isFinite(trace.requestedMediaAvailableAt)
            && !state.positiveAdState
            && state.video?.paused === false
            && state.video?.readyState >= 2
            && Number.isFinite(state.video?.currentTime)
            && Number.isFinite(trace.requestedMediaInitialCurrentTime)
            && state.video.currentTime > trace.requestedMediaInitialCurrentTime + 0.05
            && !Number.isFinite(trace.requestedPlaybackStartedAt)) {
            trace.requestedPlaybackStartedAt = now;
            recordMediaTraceEvent(cycle, "requested-playback-progressed", state);
            completeSeekTrace(cycle, state, "requested-playback-started");
        }

    }

    const scheduleSeekTracePoll = cycle => {
        clearTracePoll();
        const poll = () => {
            const trace = cycle?.intervention?.trace;
            if (!trace || trace.traceCompleted) return;
            const state = collectState();
            observeSeekTrace(cycle, state);
            if (trace.traceCompleted) return;
            if (traceOffset(trace) >= handoffTraceTimeoutMs) {
                completeSeekTrace(cycle, state, "trace-timeout");
                return;
            }
            sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
            tracePollTimer = setTimeout(poll, handoffTracePollMs);
        };
        tracePollTimer = setTimeout(poll, handoffTracePollMs);
    };

    const makeSeekTrace = (cycle, state, target, mode = "seek-attempt") => {
        if (!diagnosticsEnabled) return null;
        const trace = {
            mode,
            startedAt: performance.now(),
            currentTimeBeforeAssignment: finiteMediaNumber(state.video?.currentTime),
            requestedTarget: target,
            currentTimeAfterAssignment: null,
            seekableStartBeforeAssignment: seekableBounds(state.video).start,
            seekableEndBeforeAssignment: seekableBounds(state.video).end,
            seekableStartAfterAssignment: null,
            seekableEndAfterAssignment: null,
            assignmentAppearedAccepted: null,
            currentTimeSnapBackDetected: false,
            mediaIdentityBefore: opaqueIdentity(state.video, "media"),
            mediaIdentityImmediatelyAfter: null,
            latestMediaIdentity: opaqueIdentity(state.video, "media"),
            playerIdentityBefore: opaqueIdentity(state.player, "player"),
            playerIdentityImmediatelyAfter: null,
            latestPlayerIdentity: opaqueIdentity(state.player, "player"),
            overlayIdentityBefore: opaqueIdentity(state.overlay, "overlay"),
            overlayIdentityImmediatelyAfter: null,
            latestOverlayIdentity: opaqueIdentity(state.overlay, "overlay"),
            mediaElementReplaced: false,
            playerElementReplaced: false,
            adOverlayElementReplaced: false,
            adOverlayRemoved: false,
            durationBeforeAssignment: finiteMediaNumber(state.video?.duration),
            latestDuration: finiteMediaNumber(state.video?.duration),
            requestedVideoDuration: null,
            requestedDurationFirstObservedAt: null,
            adPlaybackEndedAt: null,
            adStateClearedAt: null,
            requestedMediaAvailableAt: null,
            requestedMediaInitialCurrentTime: null,
            requestedPlaybackStartedAt: null,
            maximumCurrentTimeAfterAssignment: finiteMediaNumber(state.video?.currentTime),
            lastReadyState: Number.isInteger(state.video?.readyState) ? state.video.readyState : null,
            lastObservedDuration: finiteMediaNumber(state.video?.duration),
            observationOutcome: "observing",
            traceCompleted: false,
            events: [],
            observedMediaElements: new WeakSet(),
            listenerAbortController: new AbortController()
        };
        cycle.intervention.trace = trace;
        attachMediaTraceListeners(cycle, state.video);
        recordMediaTraceEvent(
            cycle,
            mode === "passive-control" ? "passive-observation-started" : "seek-before-assignment",
            state
        );
        return trace;
    };

    const finishInterventionObservation = (cycle, state, isFinal) => {
        const intervention = cycle?.intervention;
        if (!intervention || intervention.completed || !intervention.attempted) return;

        const adStateCleared = !state.positiveAdState;
        const playbackResumed = requestedPlaybackLikelyResumed(cycle, state);
        intervention.adStateCleared = adStateCleared;
        intervention.playbackResumed = playbackResumed;

        const succeeded = adStateCleared && playbackResumed;
        if (succeeded || isFinal) {
            intervention.completed = true;
            intervention.stopReason = succeeded
                ? null
                : adStateCleared
                    ? "requested-playback-not-resumed"
                    : "ad-state-not-cleared";
            sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
            clearOutcomeTimers();
            return;
        }

        // Keep observing a short transition window when ad state has cleared
        // but the requested video has not reported resumed playback yet.
        sendDiagnostic(state, diagnosticFieldsForAttempt(cycle.lastAttempt, cycle), cycle.initialSignals);
    };

    const scheduleInterventionOutcomeCheck = cycle => {
        clearOutcomeTimers();
        [1600, 4200].forEach((delay, index) => {
            outcomeTimers.push(setTimeout(() => {
                finishInterventionObservation(cycle, collectState(), index === 1);
            }, delay));
        });
    };

    const attachAdInstanceTransitionListeners = cycle => {
        const mediaElement = cycle.video;
        if (!(mediaElement instanceof HTMLMediaElement)) return;

        ["emptied", "loadedmetadata", "durationchange"].forEach(kind => {
            mediaElement.addEventListener(kind, () => {
                if (activeCycle !== cycle) return;
                const state = collectState();
                updateAdInstanceTransitionEvidence(cycle, state, kind);
                scheduleCapture();
            }, { signal: cycle.instanceTransitionAbortController.signal });
        });
    };

    const transitionEvidenceTimes = evidence => [
        evidence.emptiedAt,
        evidence.currentTimeResetAt,
        evidence.oldOverlayDepartedAt,
        evidence.newOverlayObservedAt,
        evidence.metadataLoadedAt
    ].filter(Number.isFinite);

    const resetTransitionEvidenceSignals = evidence => {
        evidence.emptiedAt = null;
        evidence.currentTimeResetAt = null;
        evidence.oldOverlayDepartedAt = null;
        evidence.newOverlayIdentity = null;
        evidence.newOverlayObservedAt = null;
        evidence.metadataLoadedAt = null;
        evidence.loadedDuration = null;
    };

    const clearAdInstanceTransitionTimer = cycle => {
        if (!cycle || cycle.transitionExpiryTimer === null) return;
        clearTimeout(cycle.transitionExpiryTimer);
        cycle.transitionExpiryTimer = null;
    };

    const beginAdInstanceTransitionWindow = (cycle, observedAt) => {
        const evidence = cycle?.transitionEvidence;
        if (!cycle || !evidence || evidence.windowClosed) return false;
        if (!Number.isFinite(evidence.windowStartedAt)) {
            evidence.windowStartedAt = observedAt;
            evidence.windowDeadlineAt = observedAt + adInstanceTransitionWindowMs;
        }
        if (cycle.transitionExpiryTimer !== null) return true;
        const remaining = Math.max(0, evidence.windowDeadlineAt - performance.now());
        cycle.transitionExpiryTimer = setTimeout(() => {
            cycle.transitionExpiryTimer = null;
            if (activeCycle !== cycle || evidence.windowClosed) return;
            evidence.windowClosed = true;
            resetTransitionEvidenceSignals(evidence);
            scheduleCapture();
        }, remaining + 25);
        return true;
    };

    const hasPendingAdInstanceTransition = cycle => {
        if (!cycle || activeCycle !== cycle) return false;
        const evidence = cycle.transitionEvidence;
        return !evidence.windowClosed
            && Number.isFinite(evidence.windowDeadlineAt)
            && performance.now() <= evidence.windowDeadlineAt;
    };

    const makeAdInstanceCycle = (
        state,
        pod,
        adInstanceIndex,
        newAdInstanceDetectionReason = null,
        previousAdInstanceOutcome = null,
        previousInterventionAdvancedPod = null
    ) => {
        const now = performance.now();
        const baselineOverlayIdentity = opaqueIdentity(state.overlay, "overlay");
        const cycle = {
            pod,
            adInstanceIndex,
            newAdInstanceDetectionReason,
            previousAdInstanceOutcome,
            previousInterventionAdvancedPod,
            attemptedControls: new WeakSet(),
            lastAttempt: null,
            adStateDetectedAt: now,
            skipControlDetectedAt: state.skipControl ? now : null,
            skipControlActionableDetectedAt: state.skipControl?.actionable ? now : null,
            skipControlPresentAtDetection: Boolean(state.skipControl),
            skipControlEverSeen: Boolean(state.skipControl),
            recognizedSkipSelector: state.skipControl?.selector ?? null,
            player: state.player,
            video: state.video,
            initialVideoDuration: Number.isFinite(state.video?.duration) ? state.video.duration : null,
            initialVideoCurrentTime: Number.isFinite(state.video?.currentTime) ? state.video.currentTime : null,
            initialSignals: [...state.signals],
            requestedVideoDurationBeforeAd: lastNormalVideoDuration,
            noSkipObservationCompleted: false,
            noSkipObservationScheduled: false,
            unskippableDetected: null,
            intervention: null,
            instanceTransitionAbortController: new AbortController(),
            transitionExpiryTimer: null,
            transitionEvidence: {
                baselineOverlayIdentity,
                lastObservedOverlayIdentity: baselineOverlayIdentity,
                windowStartedAt: null,
                windowDeadlineAt: null,
                windowClosed: false,
                emptiedAt: null,
                currentTimeResetAt: null,
                oldOverlayDepartedAt: null,
                newOverlayIdentity: null,
                newOverlayObservedAt: null,
                metadataLoadedAt: null,
                loadedDuration: null
            }
        };
        attachAdInstanceTransitionListeners(cycle);
        return cycle;
    };

    const updateAdInstanceTransitionEvidence = (cycle, state, eventKind = null) => {
        if (!cycle || activeCycle !== cycle) return false;
        const evidence = cycle.transitionEvidence;
        const now = performance.now();
        if (evidence.windowClosed) return false;
        if (Number.isFinite(evidence.windowDeadlineAt) && now > evidence.windowDeadlineAt) {
            evidence.windowClosed = true;
            resetTransitionEvidenceSignals(evidence);
            clearAdInstanceTransitionTimer(cycle);
            return false;
        }

        const overlayIdentity = opaqueIdentity(state.overlay, "overlay");
        if (!evidence.baselineOverlayIdentity
            && transitionEvidenceTimes(evidence).length === 0
            && overlayIdentity) {
            evidence.baselineOverlayIdentity = overlayIdentity;
            evidence.lastObservedOverlayIdentity = overlayIdentity;
        }

        // These signals deliberately accumulate in any order. YouTube can
        // briefly remove its positive ad classes between two ads, so only the
        // final completed set requires positive ad state.
        if (eventKind === "emptied") {
            beginAdInstanceTransitionWindow(cycle, now);
            evidence.emptiedAt = now;
        }
        if ((eventKind === "emptied" || Number.isFinite(evidence.emptiedAt))
            && Number.isFinite(state.video?.currentTime)
            && state.video.currentTime <= 0.1) {
            evidence.currentTimeResetAt ??= now;
        }

        const previousOverlayIdentity = evidence.lastObservedOverlayIdentity;
        if (previousOverlayIdentity && !overlayIdentity) {
            evidence.oldOverlayDepartedAt = now;
        } else if (overlayIdentity
            && previousOverlayIdentity
            && overlayIdentity !== previousOverlayIdentity) {
            evidence.oldOverlayDepartedAt = now;
            evidence.newOverlayIdentity = overlayIdentity;
            evidence.newOverlayObservedAt = now;
        } else if (overlayIdentity
            && !previousOverlayIdentity
            && Number.isFinite(evidence.oldOverlayDepartedAt)) {
            evidence.newOverlayIdentity = overlayIdentity;
            evidence.newOverlayObservedAt = now;
        }
        evidence.lastObservedOverlayIdentity = overlayIdentity;

        if (eventKind === "loadedmetadata"
            && Number.isFinite(state.video?.currentTime)
            && state.video.currentTime <= 1
            && conservativeAdDuration(state.video?.duration)) {
            evidence.metadataLoadedAt = now;
            evidence.loadedDuration = state.video.duration;
        }

        const evidenceTimes = [
            evidence.emptiedAt,
            evidence.currentTimeResetAt,
            evidence.oldOverlayDepartedAt,
            evidence.newOverlayObservedAt,
            evidence.metadataLoadedAt
        ];
        const completeEvidence = evidenceTimes.every(Number.isFinite);
        const signalSpan = completeEvidence
            ? Math.max(...evidenceTimes) - Math.min(...evidenceTimes)
            : Number.POSITIVE_INFINITY;

        return completeEvidence
            && signalSpan <= adInstanceTransitionWindowMs
            && now <= evidence.windowDeadlineAt
            && state.positiveAdState
            && hasConfirmedAdDOM(state)
            && state.player === cycle.player
            && state.video === cycle.video
            && overlayIdentity === evidence.newOverlayIdentity
            && Number.isFinite(state.video?.currentTime)
            && state.video.currentTime <= 1
            && conservativeAdDuration(state.video?.duration)
            && conservativeAdDuration(evidence.loadedDuration);
    };

    const finishTraceForAdInstanceAdvance = (cycle, state) => {
        const trace = cycle.intervention?.trace;
        if (!trace || trace.traceCompleted) return;
        trace.events = trace.events.filter(event => event.kind !== "current-time-snap-back");
        trace.currentTimeSnapBackDetected = false;
        recordMediaTraceEvent(cycle, "ad-instance-advanced", state);
        trace.traceCompleted = true;
        trace.observationOutcome = "ad-instance-advanced";
        trace.listenerAbortController?.abort();
        clearTracePoll();
    };

    const advanceToNextAdInstance = state => {
        const previous = activeCycle;
        if (!previous || !updateAdInstanceTransitionEvidence(previous, state)) return false;

        const interventionAdvancedPod = Boolean(
            previous.lastAttempt || previous.intervention?.attempted
        );
        const previousOutcome = interventionAdvancedPod
            ? "ad-instance-advanced"
            : "natural-ad-instance-advanced";

        if (previous.lastAttempt) {
            previous.lastAttempt.outcome = "ad-instance-advanced";
            previous.lastAttempt.skipSucceeded = true;
            previous.lastAttempt.adStateClearedAfterAttempt = false;
            previous.lastAttempt.playbackResumedAfterAttempt = false;
            previous.lastAttempt.skipControlPresentAtOutcome = Boolean(state.skipControl);
            previous.lastAttempt.successReported = true;
            previous.lastAttempt.terminal = true;
        }
        if (previous.intervention) {
            previous.intervention.outcome = previousOutcome;
            previous.intervention.completed = true;
            previous.intervention.stopReason = null;
            previous.intervention.adStateCleared = false;
            previous.intervention.playbackResumed = false;
        }
        finishTraceForAdInstanceAdvance(previous, state);
        clearOutcomeTimers();
        clearAdInstanceTransitionTimer(previous);
        previous.instanceTransitionAbortController.abort();

        sendDiagnostic(
            state,
            diagnosticFieldsForAttempt(previous.lastAttempt, previous),
            previous.initialSignals
        );

        previous.pod.skipControlHistory.push(skipControlHistoryEntry(previous));
        previous.pod.interventionHistory.push(
            interventionHistoryEntry(previous, previousOutcome, interventionAdvancedPod)
        );
        previous.pod.skipControlHistory = previous.pod.skipControlHistory.slice(-maximumAdInstanceHistory);
        previous.pod.interventionHistory = previous.pod.interventionHistory.slice(-maximumAdInstanceHistory);

        const nextIndex = previous.adInstanceIndex + 1;
        activeCycle = makeAdInstanceCycle(
            state,
            previous.pod,
            nextIndex,
            adInstanceTransitionReason,
            previousOutcome,
            interventionAdvancedPod
        );
        lastFingerprint = "";
        sendDiagnostic(state, diagnosticFieldsForAttempt(null, activeCycle), state.signals);
        return true;
    };

    const confirmAndObserveNoSkipAd = cycle => {
        if (!cycle
            || activeCycle !== cycle
            || cycle.noSkipObservationCompleted
            || cycle.lastAttempt) return;

        const state = collectState();
        if (state.skipControl) {
            cycle.skipControlEverSeen = true;
            stopNoSkipIntervention(cycle, state, "skip-control-observed");
            return;
        }
        if (!state.positiveAdState) {
            stopNoSkipIntervention(cycle, state, "ad-state-ended-before-confirmation");
            return;
        }
        if (!hasConfirmedAdDOM(state)) {
            stopNoSkipIntervention(cycle, state, "recognized-ad-dom-missing");
            return;
        }
        if (!conservativeAdDuration(state.video?.duration)) {
            stopNoSkipIntervention(cycle, state, "duration-out-of-range");
            return;
        }

        // Confirmed no-skip ads are observation-only. Preserve the diagnostic
        // handoff trace, but never alter the media timeline. Historical seek
        // events remain readable by the native schema decoder.
        cycle.unskippableDetected = true;
        cycle.noSkipObservationCompleted = true;
        cycle.intervention = {
            method: "none",
            attempted: false,
            originalDuration: state.video.duration,
            originalCurrentTime: state.video.currentTime,
            adStateCleared: null,
            playbackResumed: null,
            stopReason: "no-skip-passive-observation",
            completed: true,
            trace: null
        };
        makeSeekTrace(cycle, state, null, "passive-control");
        scheduleSeekTracePoll(cycle);
        sendDiagnostic(state, diagnosticFieldsForAttempt(null, cycle), cycle.initialSignals);
    };

    const scheduleNoSkipConfirmation = cycle => {
        setTimeout(() => confirmAndObserveNoSkipAd(cycle), noSkipObservationWindowMs);
    };

    const attemptSkipIfSafe = state => {
        // Preserve the one-intervention-per-instance guard for compatibility
        // with an in-flight older script during an extension update.
        if (activeCycle?.intervention?.attempted) {
            return diagnosticFieldsForAttempt(activeCycle.lastAttempt);
        }
        if (!interventionEnabled) {
            return {
                skipAttempted: false,
                skipSucceeded: null,
                recognizedSkipSelector: state.skipControl?.selector ?? null,
                adStateClearedAfterAttempt: null,
                skipOutcome: state.skipControl ? "not-attempted" : "no-recognized-control"
            };
        }

        if (!state.skipControl) {
            if (activeCycle.lastAttempt) {
                return diagnosticFieldsForAttempt(activeCycle.lastAttempt);
            }
            return {
                skipAttempted: false,
                skipSucceeded: null,
                recognizedSkipSelector: null,
                adStateClearedAfterAttempt: null,
                skipOutcome: "no-recognized-control"
            };
        }

        const { element, selector } = state.skipControl;
        if (activeCycle.attemptedControls.has(element)) {
            return activeCycle.lastAttempt
                ? diagnosticFieldsForAttempt(activeCycle.lastAttempt)
                : {
                    skipAttempted: false,
                    skipSucceeded: null,
                    recognizedSkipSelector: selector,
                    adStateClearedAfterAttempt: null,
                    skipOutcome: "not-attempted"
                };
        }

        if (!state.skipControl.actionable) {
            return {
                skipAttempted: false,
                skipSucceeded: null,
                recognizedSkipSelector: selector,
                adStateClearedAfterAttempt: null,
                skipOutcome: "recognized-control-not-actionable"
            };
        }

        activeCycle.attemptedControls.add(element);
        const video = document.querySelector("video.html5-main-video, video");
        const attempt = {
            selector,
            adStateDetectedAt: activeCycle.adStateDetectedAt,
            skipControlDetectedAt: activeCycle.skipControlDetectedAt ?? performance.now(),
            skipControlPresentAtDetection: activeCycle.skipControlPresentAtDetection,
            skipControlDetectedAt: activeCycle.skipControlDetectedAt,
            skipControlActionableDetectedAt: activeCycle.skipControlActionableDetectedAt,
            skipControlPresentAtActivation: Boolean(state.skipControl),
            skipControlVisibleAndEnabledAtActivation: Boolean(state.skipControl.actionable),
            initialSignals: [...state.signals],
            initialVideoCurrentTime: Number.isFinite(video?.currentTime) ? video.currentTime : null,
            initialVideoDuration: Number.isFinite(video?.duration) ? video.duration : null,
            skipSucceeded: null,
            adStateClearedAfterAttempt: null,
            playbackResumedAfterAttempt: null,
            outcome: "activation-sent",
            successReported: false,
            pendingReported: false,
            terminal: false
        };
        activeCycle.lastAttempt = attempt;

        try {
            attempt.clickAt = performance.now();
            element.click();
            scheduleOutcomeCheck(attempt);
        } catch (_) {
            attempt.outcome = "activation-failed";
            attempt.skipSucceeded = false;
            attempt.adStateClearedAfterAttempt = false;
        }
        return diagnosticFieldsForAttempt(attempt);
    };

    const capture = () => {
        scheduled = false;
        const state = collectState();
        const now = performance.now();

        // A successful skip/seek can briefly clear YouTube's ad classes before
        // the next ad emits emptied/metadata. Anchor one hard, non-renewable
        // continuity window at that first gap so the pod cannot be torn down
        // before the remaining transition evidence arrives.
        const interventionWasIssued = Boolean(
            activeCycle?.lastAttempt || activeCycle?.intervention?.attempted
        );
        if (activeCycle && !state.positiveAdState && interventionWasIssued) {
            beginAdInstanceTransitionWindow(activeCycle, now);
        }

        // Accumulate overlay/time evidence even during YouTube's short gap
        // between ads, when ad-showing/ad-interrupting can be temporarily off.
        if (activeCycle) updateAdInstanceTransitionEvidence(activeCycle, state);

        if (!state.positiveAdState && Number.isFinite(state.video?.duration) && state.video.duration > 0) {
            lastNormalVideoDuration = state.video.duration;
        }

        if (!state.positiveAdState) {
            if (activeCycle?.intervention?.trace && !activeCycle.intervention.trace.traceCompleted) {
                observeSeekTrace(activeCycle, state);
            }
            if (activeCycle?.lastAttempt) {
                finishAttemptObservation(activeCycle.lastAttempt, state, true);
            }
            if (activeCycle?.intervention && !activeCycle.intervention.completed) {
                finishInterventionObservation(activeCycle, state, false);
            }
            const interventionPending = Boolean(
                activeCycle?.intervention && !activeCycle.intervention.completed
            );
            const tracePending = Boolean(
                activeCycle?.intervention?.trace && !activeCycle.intervention.trace.traceCompleted
            );
            const adInstanceTransitionPending = hasPendingAdInstanceTransition(activeCycle);
            if (interventionPending || tracePending || adInstanceTransitionPending) return;
            clearOutcomeTimers();
            clearTracePoll();
            clearAdInstanceTransitionTimer(activeCycle);
            activeCycle?.instanceTransitionAbortController?.abort();
            activeCycle = null;
            activePod = null;
            lastFingerprint = "";
            return;
        }

        if (!activeCycle) {
            activePod = {
                skipControlHistory: [],
                interventionHistory: []
            };
            activeCycle = makeAdInstanceCycle(state, activePod, 1);
        } else {
            advanceToNextAdInstance(state);
        }

        if (!activeCycle.skipControlDetectedAt && state.skipControl) {
            activeCycle.skipControlDetectedAt = now;
        }
        if (state.skipControl?.actionable && !activeCycle.skipControlActionableDetectedAt) {
            activeCycle.skipControlActionableDetectedAt = now;
        }
        if (state.skipControl) {
            activeCycle.skipControlEverSeen = true;
            activeCycle.recognizedSkipSelector ??= state.skipControl.selector;
        }

        // Mutation callbacks can arrive after a user-visible transition but
        // before YouTube removes its ad classes. Re-evaluate the same attempt
        // without issuing another activation.
        if (activeCycle.lastAttempt) {
            finishAttemptObservation(activeCycle.lastAttempt, state, false);
        }
        if (activeCycle.intervention && !activeCycle.intervention.completed) {
            finishInterventionObservation(activeCycle, state, false);
        }
        if (activeCycle.intervention?.trace && !activeCycle.intervention.trace.traceCompleted) {
            observeSeekTrace(activeCycle, state);
        }

        const interventionFields = attemptSkipIfSafe(state);
        sendDiagnostic(state, interventionFields);
        if (!activeCycle.noSkipObservationCompleted && !activeCycle.noSkipObservationScheduled) {
            scheduleNoSkipConfirmation(activeCycle);
            activeCycle.noSkipObservationScheduled = true;
        }
    };

    const scheduleCapture = () => {
        if (scheduled) return;
        scheduled = true;
        setTimeout(capture, 175);
    };

    let protectionObserver = null;
    const configureProtection = () => chrome.runtime.sendMessage({ kind: "diagnosticStatus" })
        .then(response => {
            diagnosticsEnabled = false;
            interventionEnabled = response?.ok === true && response?.interventionEnabled === true;
            if (!interventionEnabled) {
                protectionObserver?.disconnect();
                return;
            }
            protectionObserver ??= new MutationObserver(scheduleCapture);
            const start = () => {
                if (!interventionEnabled) return;
                protectionObserver.observe(document.documentElement, {
                    subtree: true,
                    childList: true,
                    attributes: true,
                    attributeFilter: ["class", "id", "aria-label", "aria-disabled", "disabled", "hidden", "data-ad-state", "data-ad-type", "data-layer", "data-player-state"]
                });
                scheduleCapture();
            };
            if (document.documentElement) start();
            else document.addEventListener("DOMContentLoaded", start, { once: true });
        })
        .catch(() => { interventionEnabled = false; protectionObserver?.disconnect(); });
    chrome.runtime.onMessage.addListener(message => {
        if (message?.kind === "refreshProtection") configureProtection();
    });
    window.addEventListener("pageshow", configureProtection);
    configureProtection();
})();
