import {SOURCES} from "../lib/catalogs.js";
const sourceName = id => SOURCES.find(source => source.id === id)?.name || id;
const $ = id => document.getElementById(id);
const format = value => Number(value || 0).toLocaleString();
let state, localBusy = false, refreshTimer;
async function message(kind, fields = {}) {
  const result = await chrome.runtime.sendMessage({kind, ...fields});
  if (!result?.ok) throw new Error(result?.error || "The extension could not complete this action.");
  return result;
}
function showError(error) { $("error").textContent = error?.message || ""; $("error").hidden = !error?.message; }
function render(next) {
  state = next;
  const updating = next.updateStatus === "updating", busy = localBusy || updating;
  for (const [key, value] of Object.entries(next.settings)) {
    const element = $(key);
    if (element) { element.checked = value; element.disabled = busy; }
  }
  $("status").textContent = updating ? "UPDATING" : next.settings.shieldActive ? "SHIELD ACTIVE" : "SHIELD PAUSED";
  $("status").classList.toggle("paused", !next.settings.shieldActive);
  $("networkCount").textContent = `${format(next.installedNetworkRules)} network rules`;
  const report = next.report, selection = report.selection;
  $("coverage").textContent = !report.sources.length ? "Factory rules active. Download maintained filters for broader coverage."
    : selection.omitted ? `Selected coverage · ${format(selection.omitted)} supported rules omitted by the browser budget.`
    : report.limitedCoverage ? "Supported filter subset active. Some upstream syntax is unsupported." : "All supported network rules fit the browser budget.";
  $("updated").textContent = next.lastSuccess ? `Last updated ${new Date(next.lastSuccess).toLocaleString()}` : "Maintained filters have not been downloaded yet.";
  $("accessDescription").textContent = next.pageCleanupGranted ? "Page cleanup can run on websites you allow in the browser."
    : next.youtubeGranted ? "YouTube access granted. General page cleanup still needs website access." : "Allow page access to hide ad spaces and activate YouTube controls.";
  $("grantCleanup").disabled = next.pageCleanupGranted || busy;
  $("grantCleanup").textContent = next.pageCleanupGranted ? "Page cleanup allowed" : "Enable page cleanup";
  $("grantYouTube").disabled = next.youtubeGranted || busy;
  $("grantYouTube").textContent = next.youtubeGranted ? "YouTube allowed" : "Allow YouTube";
  $("updateFilters").disabled = busy;
  $("updateFilters").textContent = updating ? "Updating filters…" : localBusy ? "Working…" : "Update filters";
  if ($("restorePrevious")) $("restorePrevious").disabled = busy;
  showError(next.lastError ? new Error(next.lastError) : null);
  if ($("sourceRows")) {
    $("sourceRows").replaceChildren();
    for (const source of report.sources) {
      const budget = selection.perSource[source.source] || {};
      const row = document.createElement("tr");
      for (const value of [sourceName(source.source), format(budget.supported), format(budget.selected), format(budget.omitted), format(source.cosmetics), format(source.rejected)]) {
        const cell = document.createElement("td"); cell.textContent = value; row.append(cell);
      }
      $("sourceRows").append(row);
    }
    $("budgetNote").textContent = `The dynamic update budget is ${format(report.capacity)} rules. Six slots are reserved for factory and Caregiver Shield rules. Every supported exception is retained; Scroll site fixes are retained before remaining slots are balanced between advertising and privacy rules. Cosmetic selectors use a separate CSS layer. Duplicate rules are counted once. Site fixes version: ${report.siteFixVersion || "not downloaded"}.`;
    $("rejections").textContent = report.sources.length ? report.sources.map(source => `${sourceName(source.source)}\n${Object.entries(source.reasons).map(([reason, count]) => `  ${reason}: ${format(count)}`).join("\n") || "  No rejected rules."}`).join("\n\n") : "No maintained lists downloaded yet.";
  }
}
async function refresh() {
  try { render(await message("getState")); }
  catch (error) { showError(error); }
}
async function action(kind, fields) {
  localBusy = true; if (state) render(state);
  try { render(await message(kind, fields)); }
  catch (error) { await refresh(); showError(error); }
  finally { localBusy = false; if (state) { const text = $("error").textContent; render(state); if (text) showError(new Error(text)); } }
}
for (const key of ["shieldActive", "caregiverShieldActive", "blocksNagScreens", "advancedProtectionActive"]) {
  $(key).addEventListener("change", event => action("setSettings", {changes: {[key]: event.target.checked}}));
}
$("updateFilters").addEventListener("click", () => action("updateFilters"));
$("restorePrevious")?.addEventListener("click", () => action("restorePrevious"));
$("openOptions")?.addEventListener("click", () => chrome.runtime.openOptionsPage());
$("manageAccess")?.addEventListener("click", () => chrome.tabs.create({url: `chrome://extensions/?id=${chrome.runtime.id}`}));
function permissionButton(id, origins) {
  $(id).addEventListener("click", () => {
    // Request immediately during the click's user gesture, before asynchronous work.
    chrome.permissions.request({origins}).then(async granted => {
      if (granted) await action("syncPermissions");
      else showError(new Error("Site access was not granted. Network blocking remains available."));
    }).catch(showError);
  });
}
permissionButton("grantCleanup", ["http://*/*", "https://*/*"]);
permissionButton("grantYouTube", ["https://youtube.com/*", "https://*.youtube.com/*"]);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !["settings", "report", "updateStatus", "lastError", "lastSuccess"].some(key => key in changes)) return;
  clearTimeout(refreshTimer); refreshTimer = setTimeout(refresh, 100);
});
refresh();
