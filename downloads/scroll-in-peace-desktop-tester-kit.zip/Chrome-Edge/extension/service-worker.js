import {ProtectionController, cosmeticCSS, isYouTube} from "./lib/protection.js";

const api = chrome;
const controller = new ProtectionController(api);
let mutationQueue = Promise.resolve();
function enqueue(operation) {
  const job = mutationQueue.then(operation, operation);
  mutationQueue = job.catch(() => {});
  return job;
}
function pageHost(sender) {
  if (sender.id !== api.runtime.id || !sender.tab || !sender.documentId) throw new Error("Unrecognized page sender.");
  const url = new URL(sender.url || "");
  if (!["http:", "https:"].includes(url.protocol)) throw new Error("Unsupported page.");
  return url.hostname.toLowerCase();
}
function isExtensionPage(sender) {
  return sender.id === api.runtime.id && sender.url?.startsWith(api.runtime.getURL("ui/"));
}

async function synchronizeScripts() {
  const permissions = await api.permissions.getAll();
  const origins = (permissions.origins || []).filter(origin => origin.startsWith("http://") || origin.startsWith("https://"));
  // Required download hosts do not grant permission to inject cleanup scripts.
  const matches = origins.filter(origin => !["https://easylist.to/*", "https://jocular-sherbet-13dd23.netlify.app/*"].includes(origin));
  const youtubeMatches = matches.includes("https://*/*") ? ["https://youtube.com/*", "https://*.youtube.com/*"]
    : matches.filter(origin => /^https:\/\/(?:\*\.)?(?:[a-z0-9-]+\.)*youtube\.com\//.test(origin));
  const registered = await api.scripting.getRegisteredContentScripts();
  if (registered.length) await api.scripting.unregisterContentScripts({ids: registered.map(script => script.id)});
  if (matches.length) {
    await api.scripting.registerContentScripts([
      {id: "cosmetic-cleanup", matches, js: ["content/cosmetic-filtering.js"], runAt: "document_start", allFrames: true, persistAcrossSessions: true},
      {id: "youtube-protection", matches: youtubeMatches, js: ["content/youtube-advanced-protection.js"], runAt: "document_start", allFrames: false, persistAcrossSessions: true},
    ].filter(script => script.id !== "youtube-protection" || youtubeMatches.length));
  }
}

async function refreshOpenPages() {
  const tabs = await api.tabs.query({});
  await Promise.allSettled(tabs.map(tab => api.tabs.sendMessage(tab.id, {kind: "refreshProtection"})));
}
async function publicState() {
  await controller.initialize();
  const state = await api.storage.local.get(["settings", "report", "updateStatus", "lastError", "lastSuccess"]);
  const permissions = await api.permissions.getAll();
  const network = await api.declarativeNetRequest.getDynamicRules();
  return {settings: state.settings, report: state.report, updateStatus: state.updateStatus,
    lastError: state.lastError || "", lastSuccess: state.lastSuccess || null, installedNetworkRules: network.length,
    pageCleanupGranted: (permissions.origins || []).includes("https://*/*") && (permissions.origins || []).includes("http://*/*"),
    youtubeGranted: (permissions.origins || []).includes("https://*/*") || (permissions.origins || []).some(origin => origin.includes("youtube.com")),
    origins: permissions.origins || []};
}

const cssQueues = new Map();
async function applyCosmetics(sender, previousCSS = "", clear = false) {
  const host = pageHost(sender);
  const id = sender.documentId;
  const operation = async () => {
    await controller.initialize();
    const state = await controller.read();
    const css = clear ? "" : cosmeticCSS(host, state.dataset, state.settings);
    const existing = typeof previousCSS === "string" ? previousCSS : "";
    if (existing === css) return {applied: true};
    const target = {tabId: sender.tab.id, documentIds: [id]};
    // Each selector is a separate CSS rule: a browser-unsupported selector cannot invalidate the others.
    if (css) await api.scripting.insertCSS({target, css, origin: "USER"});
    try {
      if (existing) await api.scripting.removeCSS({target, css: existing, origin: "USER"});
    } catch (error) {
      if (css) await api.scripting.removeCSS({target, css, origin: "USER"}).catch(() => {});
      throw error;
    }
    return {applied: true, css};
  };
  const job = (cssQueues.get(id) || Promise.resolve()).then(operation, operation);
  cssQueues.set(id, job);
  try { return await job; }
  finally { if (cssQueues.get(id) === job) cssQueues.delete(id); }
}

api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handle = async () => {
    if (!message || typeof message.kind !== "string") throw new Error("Invalid message.");
    if (message.kind === "applyCosmetics") return applyCosmetics(sender, message.previousCSS, message.clear === true);
    if (message.kind === "diagnosticStatus") {
      if (!isYouTube(pageHost(sender))) throw new Error("YouTube access required.");
      await controller.initialize();
      const state = await controller.read();
      const url = new URL(sender.url);
      const allowed = await api.permissions.contains({origins: [`${url.protocol}//${url.hostname}/*`]});
      return {diagnosticsEnabled: false, interventionEnabled: allowed && state.settings.advancedProtectionActive, schemaVersion: 1};
    }
    // Production never stores or forwards browsing diagnostics.
    if (message.kind === "youtubeAdState") return {accepted: false};
    if (!isExtensionPage(sender)) throw new Error("This action is available only from extension controls.");
    if (message.kind === "getState") return publicState();
    if (message.kind === "setSettings") return enqueue(async () => { await controller.setSettings(message.changes); await refreshOpenPages(); return publicState(); });
    if (message.kind === "updateFilters") return enqueue(async () => { await controller.update(true); await refreshOpenPages(); return publicState(); });
    if (message.kind === "restorePrevious") return enqueue(async () => { await controller.restorePrevious(); await refreshOpenPages(); return publicState(); });
    if (message.kind === "syncPermissions") return enqueue(async () => { await synchronizeScripts(); await refreshOpenPages(); return publicState(); });
    throw new Error("Unknown message.");
  };
  handle().then(result => sendResponse({ok: true, ...result}), error => sendResponse({ok: false, error: error.message}));
  // Compatible async messaging on Chrome/Edge versions before browser.* Promise listeners.
  return true;
});

function startup(update = false) {
  enqueue(async () => {
    await controller.initialize(); await synchronizeScripts();
    if (update) await controller.update();
    await refreshOpenPages();
  }).catch(error => console.error("Scroll in Peace:", error.message));
}
api.runtime.onInstalled.addListener(() => startup(true));
api.runtime.onStartup.addListener(() => startup(true));
api.alarms.onAlarm.addListener(alarm => { if (alarm.name === "filter-maintenance") startup(true); });
api.permissions.onAdded.addListener(() => startup());
api.permissions.onRemoved.addListener(() => startup());
