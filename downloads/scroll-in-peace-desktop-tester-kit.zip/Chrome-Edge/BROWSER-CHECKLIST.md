# Browser release checks

Run these in a clean Chrome profile and a clean Microsoft Edge profile. Automated fixture checks do not establish real YouTube compatibility or native prompt behavior.

- Load the `extension` directory with Developer mode / Load unpacked. Inspect extension errors and the service worker console.
- Confirm factory blocking is available immediately and a maintained update finishes. Check that selected, omitted, unsupported, and per-source counts are visible.
- Deny website access and confirm network blocking still works. Grant YouTube only; confirm unrelated sites receive no content scripts. Grant general website access and reload the test pages.
- Check YouTube desktop watch pages with real skippable ads, sequential ad pods, unskippable ads, Shorts, navigation between videos, background tabs, and player replacement. Verify only recognized visible/enabled Skip Ad controls are activated and normal media time is unchanged.
- Toggle Advanced Protection off and on while a page is open. Toggle the main Shield independently.
- Inspect TVGuide, FoxNews, CamdenChat, and ordinary sites for ad cleanup, article visibility, reserved ad space, consent overlays, scrolling, log-in controls, and embedded frames.
- Disable nag-screen hiding and confirm its CSS is removed on existing permitted pages. Pause the Shield and confirm both network rules and cosmetic effects disappear; resume them.
- Test offline updates, an upstream server error, browser shutdown during download/commit, service-worker suspension, and a restart. Confirm installed rules are retained and pending transactions reconcile.
- Restore the previous generation after an update. Confirm current switch settings stay in place.
- Revoke site access through the browser and reload affected tabs. Confirm scripts do not run outside allowed sites. Check browser internal/restricted pages.
- Enable private browsing access explicitly in the browser, if desired, and check its behavior separately.
- Inspect installed permission declarations, network traffic, attribution/license notices, and store-facing privacy/support identity before publishing.
- Reload an unpacked extension after edits and check for duplicate page observers or stale CSS. Reload test tabs if an older content script remains attached.

For Edge, review the manifest/API support and verify browser-specific extension management links. No `update_url` or Chrome-specific store identifier is included in this package.
